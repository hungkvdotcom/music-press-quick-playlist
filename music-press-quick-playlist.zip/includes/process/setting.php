<div class="wrap">
    <h2>Music Press Quick Playlist Setting page</h2>
</div>