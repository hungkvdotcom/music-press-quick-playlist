<?php

class MusicPressQuickPlayListFrontend {

}