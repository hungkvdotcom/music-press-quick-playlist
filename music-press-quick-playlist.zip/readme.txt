=== User profile ===
	Contributors: hungkvdotcom
	Donate link: https://wpmusicpress.com/
        Tags:  music press, quick playlist, music member
	Requires at least: 4.1
	Tested up to: 4.9.5
	Stable tag: 2.0.10
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==